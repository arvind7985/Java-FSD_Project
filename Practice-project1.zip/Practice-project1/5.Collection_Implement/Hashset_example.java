package simplelearn.collection;
import java.util.*;

public class Hashset_example {
	public static void main(String[] args) {
		
		
		HashSet<Integer> s= new HashSet<Integer>();
		
		s.add(20);
		s.add(55);
		s.add(2);
		s.add(36);
		s.add(67);
		s.add(67);
		s.add(null);
		
		System.out.println("Size: "+s.size());
		
		System.out.println(s);
		
		System.out.println("Contains: "+ s.contains(55));
		
		
		//methods add, remove,contains and size;
		

}
}