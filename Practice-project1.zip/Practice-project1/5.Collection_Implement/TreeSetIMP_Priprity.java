package simplelearn.collection;

import java.util.*;

public class TreeSetIMP_Priprity {
	public static void main(String [] args) {

	Set<Integer> s= new TreeSet<Integer>();
	
	s.add(20);
	s.add(55);
	s.add(2);
	s.add(36);
	s.add(67);
	
	
	System.out.println("Size: "+s.size());
	
	System.out.println(s);
	
	System.out.println("Contains: "+ s.contains(55));
	System.out.println("Priority-Queue Implement ");
	
	PriorityQueue<Integer> p= new PriorityQueue<Integer>();
	p.add(20);
	p.add(55);
	p.add(2);
	p.add(5);
	p.add(67);
	System.out.println(p);
	System.out.println("top "+p.peek());
	
	
	

}
}