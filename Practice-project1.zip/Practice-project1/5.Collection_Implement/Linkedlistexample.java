package simplelearn.collection;
import java.util.*;

public class Linkedlistexample {
public static void main(String[] args) {
		
		LinkedList<Integer> list= new LinkedList<Integer>();
		
		list.add(5);
		list.add(67);
		list.add(9);
	
		
		System.out.println("Size: "+list.size());
		System.out.println(list);
		
		list.remove(2);
		
		System.out.println(list);
		
		System.out.println("Element 2: "+list.get(1));
		list.add(2,0);
		
		System.out.println(list);
		
		
		
	}

}
