package simplelearn.collection;
import java.util.ArrayList;
public class ArrayListDemo {
public static void main(String[] args)
{
	ArrayList<String>arr=new ArrayList<String>();
	System.out.println("size "+arr.size());
	arr.add("Arvind");
	arr.add("shubham");
	arr.add("ravi");
	System.out.println("After Adding an Elements :"+arr.size());
	System.out.println(arr);
	
	System.out.println("Element at index 2: "+arr.get(2));
	System.out.println("ravi present :"+arr.contains("ravi"));
	arr.remove("ravi");
	System.out.println(arr);
	// loop 
	for(String s:arr) {
		System.out.println("Using For Loop: "+s);
	}

	
}

}
