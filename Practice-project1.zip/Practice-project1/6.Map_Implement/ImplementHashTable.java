package simplelearn;


import java.util.*;

public class ImplementHashTable {
public static void main(String[] args) {
		
		
		Hashtable<Integer,String> map=new Hashtable<Integer, String>();
		
		map.put(1, "apple");
		map.put(2, "mango");
		
		map.put(3, "banana");
		
		//map.put(4, null); //in hashtable we can not use the null value
		map.put(5, "orange");
		System.out.println(map);
		System.out.println("Get element at key 3: "+map.get(3));
		
		
		//remove
		
		map.remove(3);
		
		
		
		// for loop
		
		for (Map.Entry m:map.entrySet()) {
			
			System.out.println(m.getKey()+ " , "+m.getValue());
		}
	}

}
