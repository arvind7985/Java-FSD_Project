package simplelearn;
import java.util.*;

public class ImplementMap {
	
	public static void main(String[] args) {
		
		
		HashMap<Integer,String> map=new HashMap<Integer, String>();
		
		map.put(1, "apple");
		map.put(2, "mango");
		
		map.put(3, "banana");
		
		map.put(4, null); //key is not null but value is null
		map.put(null, "grafe"); //key is null but value is not null and not be added in map
	
		
		map.put(5, "orange");
		
		System.out.println(map);
		System.out.println("Get element at key 3: "+map.get(3));
		System.out.println("Get element at key null: "+map.get(null));
		
		
		// remove
		
		map.remove(null);
		
		
		
		// for loop
		
		for (Map.Entry m:map.entrySet()) {
			
			System.out.println(m.getKey()+ " , "+m.getValue());
		}
	}

}
