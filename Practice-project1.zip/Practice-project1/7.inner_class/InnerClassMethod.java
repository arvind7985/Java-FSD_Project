package simplelearn;

public class InnerClassMethod {
public void dispaly(int a) {
	
	if(a==5)	     // when a=5 then only use inner class
	{
		class Inner{
			
			int a=10;
			
			void print() 
			{
				System.out.println("Method of inner class");
				
			}
			
		}
		
		Inner ob= new Inner();
		ob.print();
	}
	else 
		System.out.println("inner class not use");
		
		
		
		
	}
	
	public static void main(String[] args) {
		
		InnerClassMethod outer= new InnerClassMethod();
		outer.dispaly(6);
		
	}

}
