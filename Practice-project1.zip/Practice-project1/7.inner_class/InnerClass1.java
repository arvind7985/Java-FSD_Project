package simplelearn;

public class InnerClass1 {
	public int a=28;
	
	
	class Inner
	{
		
		public void display()
		{
			
			System.out.println("Value of a: "+a);
			
		}
		
		
	}
	
	public static void main(String[] args) {
		InnerClass1 outer= new InnerClass1();
		InnerClass1.Inner inner = outer.new Inner();
		inner.display();
	}
}
