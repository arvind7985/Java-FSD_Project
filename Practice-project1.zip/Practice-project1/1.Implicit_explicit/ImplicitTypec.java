package simplelearn;

public class ImplicitTypec {

	public static void main(String[] args) {
		short a=4;
		int b=a;
		System.out.println("short to Int Conversion: "+b);
		
		float c=a;
		System.out.println("short to Float Conversion: "+c);
		
		double d=b;
		System.out.println("int to double Conversion: "+d);
		
		

	}

}
