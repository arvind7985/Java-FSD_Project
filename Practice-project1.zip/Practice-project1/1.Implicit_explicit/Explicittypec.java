package simplelearn;

public class Explicittypec {
	public static void main(String[] args)
	{
		double a=45;
		int b=(int)a;
		float c=9.24f;
		int d=(int)c;
		System.out.println("after typecasting value of and d-> "+b+" ,"+d);
		
	}
	

}
