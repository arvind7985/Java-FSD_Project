package simplelearn;
import java.util.*;
public class StringToBuffer {
	public static void main(String[] args) {
		  String str= new String("Hello World");
		 StringBuffer s= new StringBuffer(str);  // convert into StringBuffer
		  System.out.println("Size: "+s.length());
		  s.append("welcome");
		 System.out.println(s);
		 
		 s.insert(11, " ");
		 System.out.println(s);
		 s.reverse();
		 System.out.println(s);
	}

}
