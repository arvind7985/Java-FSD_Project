package simplelearn;

public class StringTobuilder {
	public static void main(String[] args) {
		  String str= new String("Hello World");
		 StringBuilder s= new StringBuilder(str);  // convert into StringBuilder
		  System.out.println("Size: "+s.length());
		  s.append("welcome");
		 System.out.println(s);
		 
		 s.insert(11, " ");
		 System.out.println(s);
		 s.reverse();
		 System.out.println(s);
	}

}
