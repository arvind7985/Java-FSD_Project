package simplelearn;

public class MethodOverLoading {
	public int mul(int a,int b)
	{
		return a*b;
	}
	public int mul(int a,int b,int c)
	{
		return a*b*c;
	}
public static void main(String[] args) {
		
	MethodOverLoading obj=new MethodOverLoading();
		int res=obj.mul(5,4);
		System.out.println("multification of two  no->"+res);
		int res1=obj.mul(5,4,5);
		System.out.println("multification of three  no->"+res1);
		

	}

}
