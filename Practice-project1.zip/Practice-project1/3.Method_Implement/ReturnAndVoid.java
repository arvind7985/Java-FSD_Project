package simplelearn;

public class ReturnAndVoid {
	public int mul(int a,int b)
	{
		return a*b;
	}
	public void add(int a,int b)
	{
		System.out.println("addition of two number="+(a+b));
	}

	public static void main(String[] args) {
		ReturnAndVoid obj=new ReturnAndVoid();
		int res=obj.mul(6,7);
		System.out.println("addition of two number="+res);
		obj.add(4,5);

	}

}
