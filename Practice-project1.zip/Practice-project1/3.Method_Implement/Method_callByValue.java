package simplelearn;

public class Method_callByValue {
	public int mul(int a,int b)
	{
		return a*b;
	}

	public static void main(String[] args) {
		
		Method_callByValue obj=new Method_callByValue();
		int res=obj.mul(5,4);
		System.out.println("multification of two  no->"+res);
		

	}

}
