package simplelearn.collection;
import java.util.*;

public class Array_implement {
	public static void main(String [] args) {
	
	int a[]= {1,2,3,4,5};
	
	for (int i=0;i<a.length;i++) {
		
		System.out.println(a[i]);
		
	}
	int ar[][]= {{1,2,3},{4,5,6}};
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<3;j++)
		{
			System.out.print(ar[i][j]);
		}
		System.out.print("  ");
	}
	
	}

}
