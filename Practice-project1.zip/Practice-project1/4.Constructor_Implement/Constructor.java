package simplelearn;

public class Constructor {
	int a;
	String b;
	public Constructor()
	{
		a=5;
		b="arvind";
		System.out.println("the value of a="+a);
		System.out.println("the value of b="+b);

	}
	public Constructor(int a,String b)
	{
		this.a=a;
		this.b=b;
		System.out.println("the value of a="+a);
		System.out.println("the value of b="+b);


	}
	public static void main(String[] args)
	{
		
		Constructor obj=new Constructor(7,"shubham");
		
	}
}
