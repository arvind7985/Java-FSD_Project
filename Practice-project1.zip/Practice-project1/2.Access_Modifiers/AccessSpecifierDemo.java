package simplelearn;

 class PrivateNotAccess
{
	private void methodPrivate()
	{
		System.out.println("public method");
	}
	
}
public class AccessSpecifierDemo {
	// this is for AccessSpecifier
	public void methodPublic() {
		System.out.println("public method");
	}
	
	private void methodPrivate() {
		System.out.println("private method");
	}
	
	void methodDefault() {
		System.out.println("default method");
	}
	
	protected void methodProtected() {
		System.out.println("protected method");
	}
	

	public static void main(String [] args) {
		
		AccessSpecifierDemo  obj= new AccessSpecifierDemo ();
		
		
		obj.methodDefault();
		obj.methodPrivate();
		obj.methodProtected();
		obj.methodPublic();
		PrivateNotAccess ob=new PrivateNotAccess();
		// we can not call the private function that is present in  PrivateNotAccess class if we call it give error
		
		
		
		
	
	}

}
