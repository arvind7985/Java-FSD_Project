package simplelearn.collection;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regular_Expression {

public static void main(String[] args) {
		
		String regex="[a-z]+";
		String input="tat";
		
		Pattern pattern= Pattern.compile(regex);
		
		Matcher match= pattern.matcher(input);
		
		if (match.matches()) {
			System.out.println(" Matched");
		}
		else {
			System.out.println(" Input");
		}
		
	}
}
